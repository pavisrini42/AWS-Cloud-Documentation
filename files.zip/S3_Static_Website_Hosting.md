# Static Website Hosting Using AWS S3 Bucket

> A comprehensive guide to hosting a static website on Amazon S3 with step-by-step instructions, security configurations, and practical examples.

## 📋 Table of Contents

- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Step-by-Step Guide](#step-by-step-guide)
  - [1. Create an S3 Bucket with ACL Enabled](#1-create-an-s3-bucket-with-acl-enabled)
  - [2. Upload Files to Your Bucket](#2-upload-files-to-your-bucket)
  - [3. Enable Static Website Hosting](#3-enable-static-website-hosting)
  - [4. Access Your Hosted Website](#4-access-your-hosted-website)
- [Key Concepts](#key-concepts)
- [Troubleshooting](#troubleshooting)
- [Best Practices](#best-practices)

---

## Overview

Amazon S3 (Simple Storage Service) provides a cost-effective, scalable solution for hosting static websites. This guide walks you through the complete process of setting up, configuring, and accessing a static website hosted on AWS S3.

**What You'll Learn:**
- Creating and configuring S3 buckets
- Managing bucket permissions and ACL settings
- Uploading website files to your bucket
- Enabling static website hosting features
- Retrieving and accessing your hosted website

**Estimated Time:** 15-20 minutes  
**Cost:** S3 storage and data transfer charges apply (see [AWS Pricing](https://aws.amazon.com/s3/pricing/))

---

## Prerequisites

Before you begin, ensure you have:

- ✅ An active AWS account with appropriate permissions
- ✅ Basic understanding of AWS Console navigation
- ✅ Website files ready (HTML, CSS, JavaScript, images)
- ✅ S3 bucket creation permissions (IAM policy: `s3:CreateBucket`)
- ✅ File upload permissions (IAM policy: `s3:PutObject`)

**Note:** If you don't have an AWS account, [create one here](https://aws.amazon.com/).

---

## Step-by-Step Guide

### 1. Create an S3 Bucket with ACL Enabled

#### What is an S3 Bucket?
An S3 bucket is a container for storing objects (files) in AWS. Bucket names must be globally unique and follow specific naming conventions.

#### What is ACL?
Access Control List (ACL) allows you to define who can access your bucket and its contents. Enabling ACL provides additional granular control over permissions.

#### Instructions:

1. **Sign in to AWS Console**
   - Navigate to [AWS Management Console](https://console.aws.amazon.com/)
   - Sign in with your credentials

2. **Access S3 Service**
   - Click **Services** in the top navigation bar
   - Search for and select **S3** (or click the S3 link under Storage)

3. **Create a New Bucket**
   - Click the **Create bucket** button (orange button in the Buckets section)
   - The Create bucket dialog will open

4. **Configure Bucket Settings**
   - **Bucket name:** Enter a unique name (e.g., `mywebsite-s3-hosting`)
     - Must contain only lowercase letters, numbers, and hyphens
     - Must be unique across all AWS accounts
   - **Region:** Select your region (e.g., ap-south-1 for Asia Pacific Mumbai)
   - Click **Create bucket** button

5. **Enable ACL**
   - In the bucket list, find your newly created bucket
   - Click on the bucket name to open its settings
   - Navigate to the **Permissions** tab
   - Under **Access Control List (ACL)**, verify that ACL is enabled
   - Configure ACL permissions as needed for your use case

**Visual Reference:**
```
AWS Console → S3 → Create bucket → Enter bucket name and region → Enable ACL
```

---

### 2. Upload Files to Your Bucket

#### What Files Do You Need?

For a basic static website, prepare:
- `index.html` - Your main homepage
- `style.css` - Stylesheet for formatting
- `script.js` - JavaScript for interactivity (optional)
- Image files (`.jpg`, `.png`, etc.)

#### Upload Instructions:

1. **Open Your Bucket**
   - From the S3 Buckets list, click on your bucket name
   - You should see the **Objects** tab selected

2. **Upload Files**
   - Click the **Upload** button
   - A dialog will appear with upload options

3. **Select Files**
   - Click **Add files** to browse and select individual files, OR
   - Click **Add folder** to upload an entire directory
   - Select all your website files (HTML, CSS, images, etc.)

4. **Review Upload Settings**
   - Default settings are typically fine for static websites
   - Click **Upload** to begin the upload process

5. **Verify Upload**
   - Wait for the upload to complete (progress bar shows status)
   - You should see your files listed in the Objects tab with file type and size

**Example File Structure:**
```
pavisrini-statichosting/
├── index.html
├── profile.html
├── style.css
└── images/
    └── image.jpg
```

**Expected Output:**
```
Objects (3) Info
- 404.html           html   251.0 B    April 18, 2024
- image.jpg          jpg    64.4 KB    April 18, 2024
- profile.html       html   1.7 KB     April 18, 2024
```

---

### 3. Enable Static Website Hosting

#### What Does Static Website Hosting Do?

Static website hosting configures your S3 bucket to serve web content directly. It:
- Makes your website accessible via a public URL
- Automatically serves the index document (e.g., `index.html`)
- Handles 404 errors with a custom error page

#### Instructions:

1. **Open Bucket Properties**
   - From your bucket, click the **Properties** tab

2. **Scroll to Static Website Hosting**
   - Look for the **Static website hosting** section (near the bottom)

3. **Enable Static Website Hosting**
   - Click **Edit** on the Static website hosting section
   - Select **Enable** (radio button)

4. **Configure Hosting Options**
   - Choose hosting type: **Host a static website** (usually the default)
   - **Index document:** Enter `index.html` (your homepage file)
   - **Error document:** Enter `404.html` (optional, for custom error pages)

5. **Save Changes**
   - Click **Save changes** button
   - You should see a success message

6. **Access Your Website**
   - Once enabled, AWS displays your **Bucket website endpoint** URL
   - It looks like: `https://your-bucket-name.s3-website-ap-south-1.amazonaws.com`
   - Copy this URL for accessing your website

**Important:** Your website is now accessible, but users can only view it if:
- File permissions allow public read access, OR
- You've configured a bucket policy to allow public access

---

### 4. Access Your Hosted Website

#### Make Files Publicly Accessible

By default, S3 objects are private. To allow users to view your website:

1. **Configure Bucket Policy** (Recommended approach)
   - Go to **Permissions** tab
   - Scroll to **Bucket policy** section
   - Click **Edit**
   - Paste the following policy (replace `your-bucket-name`):

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::your-bucket-name/*"
    }
  ]
}
```

   - Click **Save changes**

2. **Block Public Access Settings** (May need to adjust)
   - Go to **Permissions** → **Block public access (bucket settings)**
   - Click **Edit**
   - Uncheck **Block all public access** (if your policy allows public access)
   - Confirm the changes

#### Access Your Website

1. **Get Your Endpoint URL**
   - Go to **Properties** tab
   - Find **Static website hosting** section
   - Copy the **Bucket website endpoint** URL

2. **Open in Browser**
   - Paste the URL into your web browser's address bar
   - Press Enter
   - Your website should load!

3. **View Individual Files**
   - Click on any file in your Objects list
   - Click the file name (e.g., `image.jpg`)
   - Click **Copy S3 URI** or use the **Open** link to view

**Example URLs:**
```
Website endpoint: https://pavisrini3webhosting.s3.ap-south-1.amazonaws.com
Image URL: https://pavisrini3webhosting.s3.ap-south-1.amazonaws.com/image.jpg
HTML file: https://pavisrini3webhosting.s3.ap-south-1.amazonaws.com/profile.html
```

---

## Key Concepts

### S3 Buckets
Buckets are the fundamental storage units in S3. They:
- Store objects (files) with unique keys
- Support versioning, encryption, and lifecycle policies
- Are region-specific but globally named
- Have unlimited storage capacity

### ACL (Access Control List)
ACL defines permissions for bucket access:
- **Private:** Only the bucket owner can access
- **Public Read:** Anyone can read objects
- **Public Read/Write:** Anyone can read and upload (not recommended)

### Static Website Hosting
This S3 feature:
- Serves web content via HTTP/HTTPS
- Automatically routes requests to your index document
- Handles error pages
- Provides a public endpoint URL for your website

### Object URLs
Each file in S3 has a unique URL:
```
https://{bucket-name}.s3.{region}.amazonaws.com/{object-key}
```

---

## Troubleshooting

### Problem: Website Returns 404 Error

**Cause:** Index document not found or incorrectly named

**Solution:**
1. Verify your `index.html` file is uploaded
2. Check the spelling matches exactly (case-sensitive)
3. Re-enable static website hosting and confirm the index document name

### Problem: "Access Denied" When Accessing Website

**Cause:** Files are not publicly readable

**Solution:**
1. Add the bucket policy (see Access Your Website section)
2. Disable "Block all public access" in bucket settings
3. Ensure individual files have public read permissions

### Problem: Website Takes Too Long to Load

**Cause:** Large file sizes or slow upload speeds

**Solution:**
1. Optimize images (compress to smaller file sizes)
2. Use a CDN like CloudFront for faster delivery
3. Enable S3 Transfer Acceleration in bucket settings

### Problem: Custom Domain Not Working

**Cause:** Domain DNS records not configured correctly

**Solution:**
1. Update your domain's DNS settings to point to S3 endpoint
2. Use Route 53 for DNS management (AWS native service)
3. Consider using CloudFront for custom domain support

---

## Best Practices

### Security
✅ **Do:**
- Use bucket policies instead of individual ACL
- Enable versioning to prevent accidental deletions
- Implement MFA Delete for critical buckets
- Use S3 Block Public Access for sensitive data

❌ **Don't:**
- Grant public access unless necessary
- Store sensitive information in static websites
- Use public buckets for private content

### Performance
✅ **Do:**
- Compress images before uploading
- Use CloudFront CDN for global distribution
- Enable S3 Transfer Acceleration for faster uploads
- Implement caching headers

❌ **Don't:**
- Upload unoptimized large files
- Rely on S3 alone for global performance
- Ignore region selection

### Cost Optimization
✅ **Do:**
- Use S3 Standard storage class
- Set up lifecycle policies to archive old versions
- Monitor usage with CloudWatch
- Delete unused buckets and objects

❌ **Don't:**
- Use redundant storage classes unnecessarily
- Keep multiple versions indefinitely
- Ignore data transfer costs

### Maintenance
✅ **Do:**
- Regular backups of your website content
- Monitor bucket metrics and logs
- Keep software dependencies updated
- Document your setup and configurations

❌ **Don't:**
- Assume data is safe without backups
- Ignore AWS security notifications
- Leave default configurations in production

---

## Advanced Topics

### Connect Custom Domain
To use your own domain (e.g., `www.mysite.com`):
1. Register domain with Route 53 or external registrar
2. Create a new bucket matching your domain name
3. Configure DNS ALIAS records pointing to S3 endpoint
4. Consider CloudFront for HTTPS support

### Use CloudFront CDN
For faster global access:
1. Create a CloudFront distribution
2. Set S3 bucket as origin
3. Configure caching policies
4. Use custom SSL certificate for HTTPS

### Implement Custom Error Pages
1. Create `404.html` file
2. Upload to S3 bucket
3. Enable static website hosting
4. Set "Error document" to `404.html`

---

## Conclusion

You now have a fully functional static website hosted on AWS S3! This cost-effective solution is ideal for:
- Portfolio websites
- Documentation sites
- Blogs
- Landing pages
- Static content sites

For additional help, visit [AWS S3 Documentation](https://docs.aws.amazon.com/s3/) or AWS Support.

---

**Author:** Pavithra Srinivasan  
**Last Updated:** April 2024  
**AWS Service:** Amazon S3  
**Region:** Asia Pacific (Mumbai) - ap-south-1

